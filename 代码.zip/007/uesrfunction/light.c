/*
 * light.c
 *
 *  Created on: 2023��5��13��
 *      Author: CLai
 */
#include "userfunction.h"
void doublelight(unsigned int i,unsigned int t)//iΪ��˸ѭ��������tΪ������ڳ���
{
    while(i)
    {
        Delay_Ms(t);
        GPIO_WriteBit(GPIOC, GPIO_Pin_0, 0);
        GPIO_WriteBit(GPIOC, GPIO_Pin_1, 1);
        Delay_Ms(t);
        GPIO_WriteBit(GPIOC, GPIO_Pin_0, 1);
        GPIO_WriteBit(GPIOC, GPIO_Pin_1, 0);
        i--;
    }
    GPIO_WriteBit(GPIOC, GPIO_Pin_0, 1);
    GPIO_WriteBit(GPIOC, GPIO_Pin_1, 1);
}
