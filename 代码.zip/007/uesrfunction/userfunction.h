/*
 * userfunction.h
 *
 *  Created on: 2023��5��12��
 *      Author: CLai
 */

#ifndef UESRFUNCTION_USERFUNCTION_H_
#define UESRFUNCTION_USERFUNCTION_H_

#include"ch32v30x.h"
void GPIOIOC(void);
void GPIOIOB(void);
void light(void);
char KEYFT(void);
void LEDL(char i);

#endif /* UESRFUNCTION_USERFUNCTION_H_ */
