/*
 * userfunction.c
 *
 *  Created on: 2023��5��12��
 *      Author: CLai
 */
#include "userfunction.h"

char KEYFT(void)
{
    GPIO_WriteBit(GPIOB, GPIO_Pin_4, 0);
    /*55555555555555555555555555555555555555555555555555*/
    GPIO_WriteBit(GPIOB, GPIO_Pin_3, 1);
    GPIO_WriteBit(GPIOB, GPIO_Pin_5, 0);
    GPIO_WriteBit(GPIOB, GPIO_Pin_10, 0);
    GPIO_WriteBit(GPIOB, GPIO_Pin_11, 0);
    if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_12)==1)
        return 1;
    else if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_13)==1)
        return 2;
    else if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_14)==1)
        return 3;
    /*55555555555555555555555555555555555555555555555555*/
    GPIO_WriteBit(GPIOB, GPIO_Pin_3, 0);
    GPIO_WriteBit(GPIOB, GPIO_Pin_5, 1);
    GPIO_WriteBit(GPIOB, GPIO_Pin_10, 0);
    GPIO_WriteBit(GPIOB, GPIO_Pin_11, 0);
    if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_12)==1)
        return 4;
    else if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_13)==1)
        return 5;
    else if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_14)==1)
        return 6;
    /*55555555555555555555555555555555555555555555555555*/
    GPIO_WriteBit(GPIOB, GPIO_Pin_3, 0);
    GPIO_WriteBit(GPIOB, GPIO_Pin_5, 0);
    GPIO_WriteBit(GPIOB, GPIO_Pin_10, 1);
    GPIO_WriteBit(GPIOB, GPIO_Pin_11, 0);
    if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_12)==1)
        return 7;
    else if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_13)==1)
        return 8;
    else if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_14)==1)
        return 9;
    /*55555555555555555555555555555555555555555555555555*/
    GPIO_WriteBit(GPIOB, GPIO_Pin_3, 0);
    GPIO_WriteBit(GPIOB, GPIO_Pin_5, 0);
    GPIO_WriteBit(GPIOB, GPIO_Pin_10, 0);
    GPIO_WriteBit(GPIOB, GPIO_Pin_11, 1);
    if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_12)==1)
        return 10;
    else if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_13)==1)
        return 0;
    else if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_14)==1)
        return 11;
    else
        return 16;
}


void LEDL(char i)
{
    char j;
    j=i%2;
    if(i<10)                //��iΪ���������������ż�Ĺ�������
    {
        GPIO_WriteBit(GPIOB, GPIO_Pin_4, 0);
        if(j==0)
        {
            GPIO_WriteBit(GPIOC, GPIO_Pin_0, 1);
            GPIO_WriteBit(GPIOC, GPIO_Pin_1, 0);
        }
        else
        {
            GPIO_WriteBit(GPIOC, GPIO_Pin_0, 0);
            GPIO_WriteBit(GPIOC, GPIO_Pin_1, 1);
        }
    }
    else if(i==16)          //��iΪ16�����κε�
    {
        GPIO_WriteBit(GPIOB, GPIO_Pin_4, 0);
        GPIO_WriteBit(GPIOC, GPIO_Pin_0, 1);
        GPIO_WriteBit(GPIOC, GPIO_Pin_1, 1);
    }
    else                    //�������������
    {
        GPIO_WriteBit(GPIOB, GPIO_Pin_4, 1);
        GPIO_WriteBit(GPIOC, GPIO_Pin_0, 1);
        GPIO_WriteBit(GPIOC, GPIO_Pin_1, 1);
    }
}
