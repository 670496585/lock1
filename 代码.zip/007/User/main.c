/********************************** (C) COPYRIGHT *******************************
* File Name          : main.c
* Author             : WCH
* Version            : V1.0.0
* Date               : 2021/06/06
* Description        : Main program body.
*********************************************************************************
* Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
* Attention: This software (modified or not) and binary are used for 
* microcontroller manufactured by Nanjing Qinheng Microelectronics.
*******************************************************************************/

/*
 *@Note
 USART Print debugging routine:
 USART1_Tx(PA9).
 This example demonstrates using USART1(PA9) as a print debug port output.

*/

#include "debug.h"
#include "oled_iic.h"
#include "ch32v30x_rng.h"

/* Global typedef */

/* Global define */

/* Global Variable */



void GPIOB_WINIT(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    //����������ر�APB2�����������ʱ�ӣ�ʹ�ܣ�APB2�����ϵ����衪��GPIOC
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3|GPIO_Pin_5|GPIO_Pin_10|GPIO_Pin_11;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;        //����ģʽ
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;       //�ٶ�
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    //�������������������GPIOC
}

void GPIOB_RINIT(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;        //����
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
/*********************************************************************
 * @fn      main
 *
 * @brief   Main program.
 *
 * @return  none
 */
    int main(void)
{
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	SystemCoreClockUpdate();
	Delay_Init();
	USART_Printf_Init(115200);	
	printf("SystemClk:%d\r\n",SystemCoreClock);
	printf( "ChipID:%08x\r\n", DBGMCU_GetCHIPID() );
	printf("This is printf example\r\n");


	GPIOC_WINIT();
	    GPIOB_WINIT();
	    GPIOB_RINIT();
    OLED_Init();
    OLED_Fill(0xFF);//ȫ������
    Delay_Ms(2000);
    OLED_Fill(0x00);//ȫ����
    Delay_Ms(2000);


    char PW[]="00";
    char password[7];
    char a=16;
    char b;

    while(1)
    {
        a=KEYFT();
        OLED_ShowStr(16*0,2,"Password",2);//����8*16�ַ�
        OLED_ShowCN(16*4+8,2,13);//Ũ
        OLED_ShowCN(16*5+8,2,14);//��
        OLED_ShowStr(16*6+8,2,":",2);
        //Delay_Ms(1000);

        if (a<=9)
        {
            sprintf(PW,"%d",a);
            b=a;
        }
        else if(a==10)
            sprintf(PW,"*");
        else if(a==11)
            sprintf(PW,"#");
        else
            sprintf(PW," ");
        OLED_ShowStr(16*7,2,PW,2);
	}
}

